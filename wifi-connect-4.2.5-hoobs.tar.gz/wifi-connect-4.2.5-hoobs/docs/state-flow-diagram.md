# WiFi Connect State Flow Diagram

![State Flow Diagram](./images/flow.png?raw=true)
